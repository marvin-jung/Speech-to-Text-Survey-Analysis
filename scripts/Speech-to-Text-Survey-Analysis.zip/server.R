# Importing essential libraries:
library(tm)
library(RColorBrewer)
library(textreadr)
library(tidyr)
library(dplyr)
library(tidytext)
library(tidyverse)
library(stringr)
library(plotly)
library(igraph)
library(ggraph)
library(janitor)
library(Matrix)
library(quanteda)
library(quanteda.textmodels)
library(ggplot2)
library(caret)
library(shiny)

#Importing all .txt files from a directory with multiple txt files
path_i<-"C:/txt files"
setwd(path_i)
nm <- list.files(path=path_i) 

#using read document to import the data:
my_txt <- data.frame(do.call(rbind, lapply(nm, function(x) paste(read_document(file=x), collapse = " "))))
colnames(my_txt) <- "text"

###################
#  DATA CLEANING  #
###################

my_txt$id <- seq.int(nrow(my_txt))
my_txt$people <- ifelse(grepl("people_person	1", my_txt$text), "1",
                        ifelse(grepl("people_person	0", my_txt$text), "0", "Unknown"))

my_txt <- my_txt %>% 
    mutate(text = strsplit(as.character(text), "q+(?=[0-9])",perl=T)) %>% 
    unnest(text)%>%
    filter(!grepl("number+[0-9]", text))%>%
    filter(!grepl('people_person', text))


my_txt$question <- substr(my_txt$text,1, 1)
my_txt$text <- removeNumbers(my_txt$text)

my_txt <- my_txt %>%
    filter(!grepl("n", question))

#Creating custom stop words that include all stop words plus other words that don't bring additional information for this analysis
custom_stop_words <- bind_rows(data_frame(word = c("question", "time","free", "people", "person"),
                                          lexicon = c("custom")), stop_words)

#converting data in a tidy format 
mydf<- my_txt %>%
    unnest_tokens(word,text)%>%
    anti_join(custom_stop_words)

#creating new variable with words adjusted
mydf$word<- ifelse(grepl("animal", mydf$word, ignore.case = T), "animals",
                   ifelse(grepl("dog", mydf$word, ignore.case = T), "dog",
                          ifelse(grepl("cat", mydf$word, ignore.case = T), "cat",
                                 ifelse(grepl("apartment", mydf$word, ignore.case = T), "apartment",
                                        ifelse(grepl("game", mydf$word, ignore.case = T), "game",
                                               ifelse(grepl("activ", mydf$word, ignore.case = T), "active",
                                                      ifelse(grepl("days", mydf$word, ignore.case = T), "day",
                                                             ifelse(grepl("hunt", mydf$word, ignore.case = T), "hunter",mydf$word))))))))

# convert dataframe to document-feature matrix (dfm)
mydf.dfm <- mydf %>% 
    # unnest_tokens(word, text) %>%
    # anti_join(mystopwords) %>% 
    anti_join(stop_words) %>% 
    count(id, word, sort = TRUE) %>% 
    arrange(id) %>% 
    cast_dfm(id, word, n)

shinyServer(function(input, output, session) {

    output$type <- renderPlotly({
        people_type <- my_txt%>%
            group_by(people)%>%
            count(people,sort = TRUE)
        
        labels1= c('Yes','No')
        plot_ly(people_type, labels = ~labels1 , values = ~n, type = 'pie',
                textposition = 'inside',
                textinfo = 'label+percent',
                marker = list(colors = c('#48d1cc','#fa8072')),
                insidetextfont = list(color = '#FFFFFF'),
                hoverinfo = 'text',
                #The 'pull' attribute can also be used to create space between the sectors
                showlegend = FALSE) %>% 
            layout(title = '<b>People Person Type<b>',
                   xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                   yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
    })
    
    #Plotting results of the token frequency of the top 10 words
    output$freq1 <- renderPrint({
        #counting frequencies for each token
        mydf_counts <- mydf %>%
            count(word, sort = TRUE)
        
        #printing results
        mydf_counts
    }) 
    
    #Plotting results of the token frequency of the top 10 words
    output$freq2 <- renderPlotly({
        mydf %>%
            count(word, sort=TRUE) %>%
            mutate(word=reorder(word,n)) %>%
            top_n(10) %>%
            ungroup() %>%
            plot_ly(x = ~n, y = ~word, type = "bar", orientation = 'h',
                    marker = list(color = 'rgb(158,232,225)')) %>% 
            layout(showlegend = FALSE, 
                   margin = list(b = 80, l = 80, r = 40, t = 50, pad = 10),
                   title = "<b>Top 10 word frequency</b>",
                   xaxis = list(title = "Relevant tokens"),
                   yaxis = list(title = ""))
    })
    
    #Plotting results of the token frequency of the top 10 words per people person
    output$freq3 <- renderPlotly({
        #counting frequencies per token
        mydf_counts <- mydf %>%
            count(people, word, sort = TRUE)
        
        #estimating total number of words per type of people:
        #For people person:
        tot_people_person <- mydf_counts %>%
            filter(people=="1")%>%
            summarize(total = sum(n))
        
        #For non people person:
        tot_non_people_person <- mydf_counts %>%
            filter(people=="0")%>%
            summarize(total = sum(n))
        
        #counting frequencies per token
        mydf_counts <- mydf %>%
            count(people, word, sort = TRUE)%>%
            mutate(tot_people= ifelse(people == "0", tot_non_people_person$total, tot_people_person$total))
        
        
        ###GRAPH 2: Token frequency of the top 10 words per people person type
        mydf_counts %>%
            group_by(people)%>%
            top_n(10,(n/tot_people)) %>%
            mutate(count = ifelse(people == "1", (n/tot_people), -(n/tot_people))) %>% 
            mutate(people = recode(people, "1" = "Yes", "0" = "No")) %>% 
            arrange(desc(abs(count))) %>%
            mutate(word = reorder(word, count)) %>%
            plot_ly(x = ~count, y = ~word, color = ~people, type = "bar", orientation = 'h',
                    colors = c('#fa8072','#48d1cc')) %>%
            layout(showlegend = TRUE,
                   barmode = 'relative',
                   legend = list(title=list(text='<b> People person? </b>')),
                   title = "<b> Word frequency by people person type</b>",
                   xaxis = list(title = "Relevant tokens", tickformat = "%"),
                   yaxis = list(title = ""))
    })
    
    # Plotting results of the token frequency of the top 10 words per question
    output$freq4 <- renderPlot({
        
        #counting frequencies per token
        mydf_counts <- mydf %>%
            count(people, word, sort = TRUE)
        
        # estimating total number of words per type of people:
        # For people person:
        tot_people_person <- mydf_counts %>%
            filter(people=="1")%>%
            summarize(total = sum(n))
        
        # For non people person:
        tot_non_people_person <- mydf_counts %>%
            filter(people=="0")%>%
            summarize(total = sum(n))
        
        # counting frequencies per token
        mydf_counts_q <- mydf %>%
            count(question, people, word, sort = TRUE)%>%
            mutate(tot_people= ifelse(people == "0", tot_non_people_person$total, tot_people_person$total))
        
        # Token frequency of the top words per people person type and question
        mydf_counts_q %>%
            group_by(people)%>%
            mutate(count = ifelse(people == "0", -(n/tot_people), (n/tot_people))) %>% 
            arrange(desc(abs(count))) %>%
            mutate(word = reorder(word, count)) %>%
            mutate(question = recode(question, "1" = "Q1: Relationship with Animals", "2" = "Q2: Favorite free time activities", "3" = "Q3: Use of social media", "4" = "Q4: Occupation")) %>% 
            top_n(input$num,(n/tot_people)) %>%
            ggplot(aes(word, count, fill = people)) + 
            geom_bar(stat = "identity") + ylab("relative frequency") +xlab("")+
            labs(title = "Word frequency by people person type")+
            scale_fill_discrete(name = "People person?", labels = c("No", "Yes"))+
            theme(legend.text = element_text(size=14),
                  axis.title.y.left = element_text(size=12),
                  title = element_text(size=14,face = "bold"),
                  strip.text.x = element_text(size = 12),
                  axis.text = element_text(size=12),
                  axis.title.x = element_text(size=10))+
            scale_y_continuous(labels=scales::percent)+
            facet_wrap(~question, scales = "free") +
            coord_flip()
    })
    
    # frequency of a term adjusted for how rarely it is used (tf-idf)
    output$TF_IDF1 <- renderPlotly({
        fig1 <- mydf %>%
            count(people, word) %>%
            bind_tf_idf(word, people, n) %>%
            filter(people == 0) %>% 
            arrange(desc(tf_idf)) %>%
            mutate(word = factor(word, levels = rev(unique(word)))) %>%
            top_n(10) %>%
            ungroup() %>% 
            plot_ly(x = ~tf_idf, y = ~word, type = "bar", orientation = 'h',
                    color = I('#fa8072')) %>%
            add_annotations(
                text = "Non People person",
                x = 0.5,
                y = 1,
                yref = "paper",
                xref = "paper",
                yanchor = "bottom",
                showarrow = FALSE
            ) %>%
            layout(
                xaxis = list(range = c(0, 0.01), title = ""),
                showlegend = FALSE,
                shapes = list(
                    type = "rect",
                    x0 = 0,
                    x1 = 1,
                    xref = "paper",
                    y0 = 0, 
                    y1 = 20,
                    yanchor = 1,
                    yref = "paper",
                    ysizemode = "pixel",
                    fillcolor = toRGB("gray80"),
                    line = list(color = "transparent")
                )
            )  
        
        fig2 <- mydf %>%
            count(people, word) %>%
            bind_tf_idf(word, people, n) %>%
            filter(people == 1) %>% 
            arrange(desc(tf_idf)) %>%
            mutate(word = factor(word, levels = rev(unique(word)))) %>%
            top_n(10) %>%
            ungroup() %>% 
            plot_ly(x = ~tf_idf, y = ~word, type = "bar", orientation = 'h',
                    color = I('#48d1cc'))%>%
            add_annotations(
                text = "People person",
                x = 0.5,
                y = 1,
                yref = "paper",
                xref = "paper",
                yanchor = "bottom",
                showarrow = FALSE
            ) %>%
            layout(
                xaxis = list(range = c(0, 0.01), title = ""),
                showlegend = FALSE,
                shapes = list(
                    type = "rect",
                    x0 = 0,
                    x1 = 1,
                    xref = "paper",
                    y0 = 0, 
                    y1 = 20,
                    yanchor = 1,
                    yref = "paper",
                    ysizemode = "pixel",
                    fillcolor = toRGB("gray80"),
                    line = list(color = "transparent")
                )
            )  
        
        subplot(fig1, fig2, margin = 0.06) %>% 
            layout(showlegend = FALSE, 
                   margin = list(b = 60, l = 80, r = 5, t = 70, pad = 5),
                   title = "<b>Frequency of a term adjusted for how rarely it is used (tf-idf)</b>")
    })
    
    # Plotting results of the token frequency of the top 5 words per question
    output$TF_IDF2 <- renderPlotly({
            fig1<-mydf %>%
            group_by(people)%>%
            filter(question == 1)%>%
            count(people, word) %>%
            bind_tf_idf(word, people, n) %>%
            mutate(count = ifelse(people == "0", -tf_idf, tf_idf)) %>% 
            arrange(desc(tf_idf)) %>%
            mutate(word = factor(word, levels = rev(unique(word)))) %>%
            top_n(2,tf_idf) %>%
            ungroup %>%
            ggplot(aes(word, tf_idf, fill = people)) +
            scale_fill_discrete(name = "People person?", labels = c("No", "Yes"))+
            geom_col(show.legend = F) +
            theme(legend.text = element_text(size=12), legend.position="right")+
            labs(title = "Q1: Animals")+
            labs(x = NULL, y = "tf-idf") +
            coord_flip()
        
             fig2<- mydf %>%
            group_by(people)%>%
            filter(question == 2)%>%
            count(people, word) %>%
            bind_tf_idf(word, people, n) %>%
            mutate(count = ifelse(people == "0", -tf_idf, tf_idf)) %>% 
            arrange(desc(tf_idf)) %>%
            mutate(word = factor(word, levels = rev(unique(word)))) %>%
            top_n(2,tf_idf) %>%
            ungroup %>%
            ggplot(aes(word, tf_idf, fill = people)) +
            scale_fill_discrete(name = "People person?", labels = c("No", "Yes"))+
            geom_col(show.legend = F) +
            theme(legend.text = element_text(size=12), legend.position="top")+
            labs(title = "Q2: Free Time")+
            labs(x = NULL, y = "tf-idf") +
            coord_flip()
        
            fig3<- mydf %>%
            group_by(people)%>%
            filter(question == 3)%>%
            count(people, word) %>%
            bind_tf_idf(word, people, n) %>%
            mutate(count = ifelse(people == "0", -tf_idf, tf_idf)) %>% 
            arrange(desc(tf_idf)) %>%
            mutate(word = factor(word, levels = rev(unique(word)))) %>%
            top_n(2,tf_idf) %>%
            ungroup %>%
            ggplot(aes(word, tf_idf, fill = people)) +
            scale_fill_discrete(name = "People person?", labels = c("No", "Yes"))+
            geom_col(show.legend = F) +
            theme(legend.text = element_text(size=12), legend.position="left")+
            labs(title = "Q3: Social Media")+
            labs(x = NULL, y = "tf-idf") +
            coord_flip()
        
            fig4<-mydf %>%
            group_by(people)%>%
            filter(question == 4)%>%
            count(people, word) %>%
            bind_tf_idf(word, people, n) %>%
            mutate(count = ifelse(people == "0", -tf_idf, tf_idf)) %>% 
            arrange(desc(tf_idf)) %>%
            mutate(word = factor(word, levels = rev(unique(word)))) %>%
            top_n(2,tf_idf) %>%
            ungroup %>%
            ggplot(aes(word, tf_idf, fill = people)) +
            scale_fill_discrete(name = "People person?", labels = c("No", "Yes"))+
            geom_col(show.legend = T) +
            labs(title = "Q4: Occupation")+
            labs(x = NULL, y = "tf-idf") +
            theme(legend.text = element_text(size=12), legend.position="left")+
            coord_flip()
        
             subplot(fig1, fig2, fig3, fig4, nrows = 2, margin = 0.1, shareX = FALSE,
                shareY = FALSE) %>%
                layout(showlegend=F,
               margin = list(b = 40, l = 50, r = 200, t = 60, pad = 4),
               title = "<b>TF-IDF per question and people-person type</b>")
        })
    
    
    # Analyzing data with the nrc dictionary
    output$sentiment <- renderPlot({
        mydf_counts <- mydf %>%
            count(people, word, sort = TRUE)

        #estimating total number of words per type of people:
        #For people person:
        tot_people_person <- mydf_counts %>%
            filter(people=="1")%>%
            summarize(total = sum(n))
        
        #For non people person:
        tot_non_people_person <- mydf_counts %>%
            filter(people=="0")%>%
            summarize(total = sum(n))
        
        #counting frequencies per token
        mydf_counts <- mydf %>%
            count(people, word, sort = TRUE)%>%
            mutate(tot_people= ifelse(people == "0", tot_non_people_person$total, tot_people_person$total))
        
        nrc_word_counts <- mydf %>%
            inner_join(get_sentiments("nrc")) %>%
            count(people,word, sentiment, sort = TRUE)  %>%
          mutate(tot_people= ifelse(people == "0", tot_non_people_person$total, tot_people_person$total))
        
        nrc_word_counts$people_person<- ifelse(grepl("1", nrc_word_counts$people), "people-person", "non people-person")
        
        nrc_word_counts%>%
            group_by(people_person) %>%
            top_n(10, (n/tot_people)) %>%
            ungroup() %>%
            mutate(count = n/tot_people) %>% 
            mutate(word=reorder(word,count)) %>%
            ggplot(aes(word, count , fill=sentiment))+
            geom_col(show.legend=T)+
            facet_wrap(~people_person,  scales="free_y") +
            labs(title = "Sentiment Analysis using the NRC Dicitionary")+
            scale_y_continuous(labels=scales::percent)+
            scale_fill_manual(values=c("#2b2272", "#6c225f", "#4fc6b4",
                                       "#f9766b", "#85d085", "#ffab35",
                                       "#9ed9d9","#0076CC"))+
            theme(axis.text = element_text(size=12),
                  axis.title = element_text(size=14,face = "bold"),
                  title = element_text(size=16,face = "bold"),
                  strip.text.x = element_text(size = 12,face = "bold"),
                legend.text = element_text(size=14),legend.position="bottom")+
            labs(y = "Contribution to sentiment",
                 x = NULL) +
            coord_flip()     
            })

    # for display of N-GRAM Analysis
    output$bigrams1 <- renderPrint({
        bigrams <- my_txt %>%
            unnest_tokens(bigram, text, token = "ngrams", n=2) %>% 
            filter(!is.na(bigram))
        bigrams %>%
            count(bigram, people, sort = TRUE) #this has many stop words, need to remove them 
        
        # removing most common words instead of stop words
        common <- c("people","free","time","do","you",
                    "consider","yourself","person",
                    "although","am","all","of",
                    "how","and","a","on","and",
                    "so","but","an","use")
        
        common_words <- data.frame(text=common)
        
        # FILTERED BIGRAMS
        bigrams_separated <- bigrams %>%
            separate(bigram, c("word1", "word2"), sep = " ")
        
        # after separating, we can remove stop words
        bigrams_filtered <- bigrams_separated %>%
            filter(!word1 %in% common_words$text) %>%
            filter(!word2 %in% common_words$text)
        
        #creating the new bigram, "no-stop-words" and count frequencies for bigrams
        bigram_counts <- bigrams_filtered %>%
            count(word1, word2, sort = TRUE)
        
        #we need to unite what we split in the previous section
        bigrams_filtered %>%
            unite(bigram, word1, word2, sep=" ") %>%  
            count(people, bigram, sort=T) %>%
            head(10)
    })
    
    output$bigrams2 <- renderPrint({
        bigrams <- my_txt %>%
            unnest_tokens(bigram, text, token = "ngrams", n=2) %>% 
            filter(!is.na(bigram))
        bigrams %>%
            count(bigram, people, sort = TRUE) #this has many stop words, need to remove them 
        
        # removing most common words instead of stop words
        common <- c("people","free","time","do","you",
                    "consider","yourself","person",
                    "although","am","all","of",
                    "how","and","a","on","and",
                    "so","but","an","use")
        
        common_words <- data.frame(text=common)
        
        # FILTERED BIGRAMS
        bigrams_separated <- bigrams %>%
            separate(bigram, c("word1", "word2"), sep = " ")
        
        # after separating, we can remove stop words
        bigrams_filtered <- bigrams_separated %>%
            filter(!word1 %in% common_words$text) %>%
            filter(!word2 %in% common_words$text)
        
        #joining two words in a bigram
        bigram_united <- bigrams_filtered %>%
            unite(bigram, word1, word2, sep=" ") %>%  
            count(people, bigram, sort=T) 
        
        # bigrams tf_idf per people person
        bigram_tf_idf <- bigram_united %>%
            bind_tf_idf(bigram, people, n) %>%
            arrange(desc(tf_idf))%>%
            filter(n>3)%>%
            filter(tf_idf>0)
        
        #showing results
        bigram_tf_idf
    })
    
    output$Ngrams <- renderPlot({
        bigrams <- my_txt %>%
            unnest_tokens(bigram, text, token = "ngrams", n=2) %>% 
            filter(!is.na(bigram))
        bigrams %>%
            count(bigram, people, sort = TRUE) #this has many stop words, need to remove them 
        
        # removing most common words instead of stop words
        common <- c("people","free","time","do","you",
                    "consider","yourself","person",
                    "although","am","all","of",
                    "how","and","a","on","and",
                    "so","but","an","use")
        
        common_words <- data.frame(text=common)
        
        # FILTERED BIGRAMS
        bigrams_separated <- bigrams %>%
            separate(bigram, c("word1", "word2"), sep = " ")
        
        # after separating, we can remove stop words
        bigrams_filtered <- bigrams_separated %>%
            filter(!word1 %in% common_words$text) %>%
            filter(!word2 %in% common_words$text)
        
        #joining two words in a bigram
        bigram_united <- bigrams_filtered %>%
            unite(bigram, word1, word2, sep=" ") %>%  
            count(people, bigram, sort=T) 
        
        #obtaining frequency per bigram and people person type
        bigram_filt_tf_idf <- bigram_united %>%
            bind_tf_idf(bigram, people, n) %>%
            arrange(desc(tf_idf))
        
        #showing results
        bigram_filt_tf_idf

        # ploting tf_idf results per people person
        bigram_filt_tf_idf %>%
            mutate(bigram = factor(bigram, levels = rev(unique(bigram)))) %>%
            group_by(people)%>%
            arrange(desc(tf_idf)) %>%
            top_n(3, tf_idf) %>%
            filter(n>3) %>%
            mutate(people = recode(people, "0" = "Non People person", "1" = "People person")) %>% 
            #ggplot(aes(bigram, n, fill = people)) + 
            ggplot(aes(bigram, tf_idf, fill = people)) + 
            geom_bar(stat = "identity") + ylab("") +xlab("")+
            labs(title = "TF-IDF Bigrams by people person type")+
            scale_fill_discrete(name = "People person?", labels = c("No", "Yes"))+
                  theme(axis.text = element_text(size=10),
                  title = element_text(size=12,face = "bold"),
                  strip.text.x = element_text(size = 12,face = "bold"),
                  legend.text = element_text(size=12))+
            facet_wrap(~people, scales = "free") +
            coord_flip()
    })
    
    # for display of frequency of a term from Naive Bayes Classifier
    output$NB_counts <- renderPlotly({
        data(stop_words)
        
        # create a target category
        category <- c(1, 0, 1, 1, 1, 0, 0, 1, 0, 1,
                      1, 1, 1, 1, 0, 1, 0, 1, 1, 1,
                      1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 
                      0, 1, 1, 1, 0, 1, 0)
        
        target <- data.frame(category)
        
        # split the docs into training and testing data
        
        mydf.dfm.train <- mydf.dfm[1:input$obs,]
        mydf.dfm.test  <- mydf.dfm[(input$obs+1):37,]
        target.train <- target[1:input$obs,]
        target.test  <- target[(input$obs+1):37,]
        
        # build the Naive Bayes model
        NB_classifier <- textmodel_nb(mydf.dfm.train, target.train)
        
        NB_matrix <- as.data.frame(t(as.table(NB_classifier$param))) 
        colnames(NB_matrix) <- c("word", "people", "freq")
        
        #estimating total number of words per type of people:
        #For people person:
        people_person <- NB_matrix %>%
            filter(people=="1")%>%
            summarize(total = sum(freq))
        
        #For non people person:
        non_people_person <- NB_matrix %>%
            filter(people=="0")%>%
            summarize(total = sum(freq))
        
        # Token frequency of the top 10 words per people person type
        NB_matrix_counts <- NB_matrix %>%
            group_by(people)%>%
            top_n(12) %>%
            mutate(count = ifelse(people == "1", freq, -freq)) %>%
            arrange(desc(abs(count))) %>%
            mutate(word = reorder(word, count)) %>%
            ggplot(aes(word, count, fill = people)) + 
            geom_bar(stat = "identity") + 
            xlab(" ") + ylab("Conditional Probability") + 
            labs(title = "Probability of a term from Naive Bayes Classifier for texts")+
            scale_fill_discrete(name = "People person?", labels = c("No", "Yes"))+
            scale_y_continuous(labels=scales::percent)+
            theme(legend.position='none') +
            coord_flip()
    })
        
    # for display of Naive Bayes model with "Confusion matrix"
    output$txtmodel_nb <- renderPrint({
        data(stop_words)
        
        # create a target category
        category <- c(1, 0, 1, 1, 1, 0, 0, 1, 0, 1,
                      1, 1, 1, 1, 0, 1, 0, 1, 1, 1,
                      1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 
                      0, 1, 1, 1, 0, 1, 0)
        
        target <- data.frame(category)
        
        # split the docs into training and testing data
        
        mydf.dfm.train <- mydf.dfm[1:input$obs,]
        mydf.dfm.test  <- mydf.dfm[(input$obs+1):37,]
        target.train <- target[1:input$obs,]
        target.test  <- target[(input$obs+1):37,]
        
        # build the Naive Bayes model
        NB_classifier <- textmodel_nb(mydf.dfm.train, target.train)
        NB_classifier
        summary(NB_classifier)
        
        # predicting the testing data
        predicted_category <- predict(NB_classifier, mydf.dfm.test)
        
        cat("Prediction\n", as.numeric(as.factor(predicted_category))-1, "\n")
        cat("\nActual\n", target.test, "\n\n")
        
        # create a confusion matrix to check the accuracy
        tab_class <- table(target.test, predicted_category)
        confusionMatrix(tab_class, mode = "everything")
        
    })
    
    # for display of mtcars dataset summary statistics in the "Menu item A page"
    output$summary <- renderPrint({
        summary(mtcars)
    })
    
})

