#install.packages("bslib")
library(shiny)
library(shinyWidgets)
library(plotly)
library(bslib)
shinyUI(navbarPage( title = "Team 14", 
                    tabPanel("Home"
                    ,setBackgroundImage(
                       src ="https://image.freepik.com/free-photo/abstract-blur-white-background-design_1962-1588.jpg"
                   ),  markdown("

   ## <center> **Natural Language Processing Analysis** </center> <p>

    # <center> **Survey: Are you a people person?** </center> <br>
   
    ### <center> Course: Text Analytics and NLP  </center> <br>
    
    ### <center> **Team 14** </center> <br>
    #### <center> Camilla Brossa </center>
    #### <center> Merve Bulgurcu </center>
    #### <center> Jacopo Casati </center>
    #### <center> Ji Sung Jung </center>
    #### <center> Lourdes Montenegro </center>

    ")
                   ),
                   
                   tabPanel("About Research", 
                            markdown(" 
    ---
    # Research Data
    
    ##### **> Survey conducted among 37 students cursing a Master Degree in Hult Business School - San Francisco:**
    
    #### 4 open-ended questions:<br>
     -	Tell us about your relationship with animals.
     -	What do you like to do in your free time and why?
     -	Tell us about your use of social media? how often do you use them?
     -	What do you do in your life?
     
    #### Plus a final binary (Yes/No) question:<br>
     -	Are you a people person?
                                     "),
                            
                            plotlyOutput("type", height = "200px"),
                            
                            markdown(" 
    # Research Objectives
    #### The research aims to:
    -	Uncover insights on what behaviors or textual patterns differentiate individuals who label themselves as people person from those who do not.
    -	Create a Naïve Bayes model to process the answers to the questions mentioned above and predict the \"people person\" label.

    "),

                   ),
                   
                   tabPanel("Text Analysis",
                      tabsetPanel(
                        id = "maintabset", type = "tabs",
                        tabPanel("Frequency Analysis", wellPanel( 
                          navlistPanel(widths = c(2, 10),
                            "Single Words",
                            tabPanel("Most common words",
                                     verbatimTextOutput("freq1")
                            ),
                            tabPanel("Top 10 most common words",
                                     plotlyOutput("freq2", height = "600px")
                            ),
                            tabPanel("Top words per people-person type",
                                     plotlyOutput("freq3", height = "500px") 
                            ),
                            tabPanel("Top words per people-person and question",
                                     sliderInput("num", "Filter:", width = "40%", min = 5, max = 20, value = 8),
                                     plotOutput("freq4", height = "450px") 
                            )
                          )
                        )),
                        tabPanel("Frequency (TF-IDF)", wellPanel(
                          navlistPanel(widths = c(2, 10),
                            "TF-IDF",
                            tabPanel("TF-IDF per people-person type",
                                     plotlyOutput("TF_IDF1", height = "500px")
                            ),
                            tabPanel("TF-IDF per people-person type and question",
                                plotlyOutput("TF_IDF2", height = "600px")
                            )
                          )
                        )),
                        tabPanel("Sentiment Analysis", wellPanel(
                            plotOutput("sentiment", height = "500px")
                        )),
                        tabPanel("N-grams Analysis", wellPanel(
                            fluidRow(
                                column(4,
                                       h6("Bigrams"),
                                       verbatimTextOutput("bigrams1"),
                                       h6("TF-IDF"),
                                       verbatimTextOutput("bigrams2")
                                ),
                                column(8,
                                       plotOutput("Ngrams", height = "600px")
                                )
                            )
                        ))
                      )
                   ),
                   
                   tabPanel("NLP Naive Bayes",
                            sidebarPanel(
                                sliderInput("obs", "Select Training observations out of 35", min = 15, max = 35, value = 30)
                            ),
                            mainPanel(
                                tabsetPanel(
                                    id = "subtabset", type = "tabs",
                                    tabPanel("Barplot", wellPanel(
                                        plotlyOutput("NB_counts", height = "500px"),
                                        img(src = "https://s2.gifyu.com/images/legend49f0289d7eaca7f6.png", width = "100%")
                                    )),
                                    tabPanel("Confusion Matrix", wellPanel(
                                        verbatimTextOutput("txtmodel_nb")
                                        )
                                    )
                                )
                            )
                   ),
                   
                   ## Use navbarmenu to get the tab with menu capabilities
                   tabPanel("Conclusion",
                              markdown("

# Conclusions
-	Regardless of the final answer, the first question is the most engaging for all the interviewed. People indulge in talking for a longer time, making words related to nature and animals the most frequent.
-	Living nature is related not to be a people person. Hunters and nature lovers are in this same cluster.
-	Talking about dogs is not indicative of affinity to a group or another while cats and hamsters are related to not being a people person.
-	Social media are used and talked about by both groups, but Instagram and Twitter suggest membership to the people person one.
-	Talking about friends is a strong indicator of being a people person.
-	A non-people person spends more time talking about jobs while a people person spends more time talking about activities and friends.


# The two segments in brief
#### **People person persona** 
- He/She is a dynamic and very active person that likes to talk about his/her free time activities. He/she tends to own a dog and is active on many social media platforms to remain connected with friends (instagram) and express his/her ideas (twitter).
#### **Non-people person persona** 
- He/She loves animals and nature where spends her/his free time, owns an animal, usually a cat or a hamster, or crave the interaction with one.  He/she only has Facebook and most probably LinkedIn since at the moment is very focused on his/her professional career.  


##### ***Limitations over the research:***
Although the insights from the research exhibit relevant information regarding the defined clusters, further research are needed to have a stronger model and statistical significance to support our findings.
The process to collect, structure, and analyze the information will be unchanged while the questions may be fine-tuned in the light of what was discovered so far to exploit influential topics and guide the interviewed in giving further personal information.
                             ")
                              )
                   )
)