1. Open Rstudio

2. Open two script files: ui.R and server.R

3. Edit text source path in server.R line 22 to avoid error.
- path_i<-"C:/txt files"

4. Run the shiny application by clicking "▶ Run App" 